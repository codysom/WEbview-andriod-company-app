package com.example.moto_op;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.support.v7.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.drawable.Drawable;
import java.util.Timer;
import java.util.TimerTask;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.Bitmap;
import android.widget.Toast;
import android.webkit.DownloadListener;
import android.content.Intent;
import android.net.Uri;
import android.app.DownloadManager;
import android.os.Environment;
import android.webkit.URLUtil;
import android.webkit.CookieManager;
import android.net.ConnectivityManager;




public class MainActivity extends AppCompatActivity {
    ProgressBar prg;
    ProgressBar pbar;
    TextView textView;
    WebView webView;
    int counter = 0;


    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        setContentView(R.layout.activity_main);

        this.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

        prog();

        final Handler h = new Handler();
        h.postDelayed(new Runnable() {

            @Override



            public void run() {


                    setContentView(R.layout.mainsite);
                    webView = (WebView) findViewById(R.id.web);
                    pbar = findViewById(R.id.progressBar1);

                    webView.setWebViewClient(new android.webkit.WebViewClient());
                    webView.getSettings().setJavaScriptEnabled(true);
                    webView.getSettings().setAppCacheEnabled(true);
                    webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
                    webView.setWebViewClient(new WebViewClient());

                    webView.loadUrl("http://www.bookson.epizy.com/");
                    webView.setWebChromeClient(new WebChromeClient() {
                        public void onProgressChanged(WebView view, int progress) {
                            pbar.setProgress(progress);
                            if (progress == 100) {
                                pbar.setVisibility(View.GONE);

                            } else {
                                pbar.setVisibility(View.VISIBLE);

                            }
                        }
                    });
                    webView.setDownloadListener(new DownloadListener() {

                        public void onDownloadStart(String url, String userAgent,
                                                    String contentDisposition, String mimetype,
                                                    long contentLength) {
                            Toast.makeText(MainActivity.this, "Downloading..Please wait", Toast.LENGTH_SHORT).show();
                            Intent i = new Intent(Intent.ACTION_VIEW);
                            i.setData(Uri.parse(url));
                            startActivity(i);

                        }
                    });



            }


        }, 3000);


    }
    @Override
    protected void onResume(){
        super.onResume();
        if(webView !=null)
        {
            webView.loadUrl("http://www.bookson.epizy.com/");

        }

    }


    @Override
    public void onBackPressed() {

        if (webView.canGoBack() == true) {
            webView.goBack();


            Toast.makeText(this,"Click continuously to exit",Toast.LENGTH_SHORT).show();

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            int imageResource = android.R.drawable.ic_dialog_alert;
            Drawable image = getResources().getDrawable(imageResource);

            builder.setTitle("Exit").setMessage("You really want to exit?").setIcon(R.drawable.logo).setCancelable(false).setPositiveButton("yes", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    finish();
                }
            }).setNegativeButton("no", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                }
            });

            AlertDialog alert = builder.create();
            alert.setCancelable(false);
            alert.show();

        }


    }

    public void prog() {
        prg = (ProgressBar) findViewById(R.id.progressBar);
        final Timer t = new Timer();
        TimerTask tt = new TimerTask() {
            @Override
            public void run() {
                counter++;

                prg.setProgress(counter);

                if (counter == 100) {
                    t.cancel();
                }
            }
        };
        t.schedule(tt, 0, 30);

    }


    public class WebViewClient extends android.webkit.WebViewClient {

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }
    }

}







